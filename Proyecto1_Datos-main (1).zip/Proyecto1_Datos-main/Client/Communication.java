package Client;

import javax.swing.*;
import java.awt.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class Communication {
    Socket sendSocket;
    ServerSocket listenSocket;

    public Communication(int listen, int send) throws IOException {

        listenSocket = new ServerSocket(listen);

    }


    public void EnviarMensaje(String message, int PORT) {

        DataOutputStream output;

        try {

            sendSocket = new Socket("localhost", PORT);
            output = new DataOutputStream(sendSocket.getOutputStream());

            output.writeUTF(message);


            System.out.println("Mensaje enviado: " + message);

            sendSocket.close();


        } catch (IOException ex) {
            System.out.println("Error");
        }
    }

    public String RecibirMensaje() {
        Socket socket = null;
        DataInputStream input;
        DataOutputStream output;

        try {


            socket = listenSocket.accept();
            System.out.println("Listening on 7777");
            input = new DataInputStream(socket.getInputStream());

            String mensaje = input.readUTF();

            System.out.println("Mensaje Recibido:" + mensaje);
            return mensaje;

        } catch (IOException ex) {
            return "Error";
        }
    }
}

class ventanaServidor extends JFrame implements Runnable { //hereda de JFrame para crear la ventana
    public ventanaServidor() {  //Constructor
        setBounds(500, 200, 400, 300); //define ubicacion en x, y , ancho, alto del cuadro
        JPanel lamina2 = new JPanel();
        lamina2.setLayout(new BorderLayout());
        setResizable(false); //evitar que la ventana se redimencione
        setTitle("Servidor");
        setVisible(true); //mostrar en pantalla


    }

    @Override
    public void run() {

    }
}

        


                