
package Server;

import Utils.*;

import javax.swing.*;  //importar interfaz grafica
import java.io.IOException;


public class PantallaInicio {


    public static void main(String[] args) throws IOException {
        Communication server = new Communication(8888, 7777);
        ventanaInicio ventana1 = new ventanaInicio(server);
        ventana1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //para que al cerrar la ventana no siga ejecutandose

    }

}

class ventanaInicio extends JFrame { //La clase hereda de JFrame para poder crear cuadros(ventanas)


    public ventanaInicio(Communication server) { //Constructor
        System.out.println("PantalaInicio");
        setBounds(500, 200, 400, 300);
        setResizable(false); //evitar que la ventana se redimencione
        setTitle("Pantalla Inicio");

        Lamina1 lamina1 = new Lamina1();
        add(lamina1);
        setVisible(true); //muestra la ventana 
        String mensaje = server.RecibirMensaje();

        JOptionPane.showMessageDialog(lamina1, "Jugador: " + mensaje + " está conectado");


        //Abre el tablero cuando se conecta el jugador 2
        Ventana ventana = new Ventana();
        LinkedList lista = new LinkedList();
        Dado dado = new Dado(ventana, lista);
        creartablero tablero = new creartablero(ventana, lista);
        ventana.setVisible(true);

        server.EnviarMensaje(lista.printList(), 7777);
    }
}

class Lamina1 extends JPanel {

    JLabel datos = new JLabel("Esperando jugadores..."); // instancia para agregar una etiqueta de texto


    public Lamina1() { //constructor

        add(datos); // se añade el texto a la lamina


    }

}
   
    

