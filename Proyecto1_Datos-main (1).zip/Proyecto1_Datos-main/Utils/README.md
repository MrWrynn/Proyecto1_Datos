# Proyecto #1 - Algoritmos y estructura de datos 1
***
## Integrantes:
- Cristopher Eduardo Moreira Quirós :shipit:
- Jose Eduardo Cruz Vargas
- Meibel Ceciliano Picado
***
