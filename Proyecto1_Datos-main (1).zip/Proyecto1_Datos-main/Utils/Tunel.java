package Utils;

import javax.swing.*;
import java.awt.Color;

public class Tunel extends Casilla {
    public void crear (Ventana ventana){
        JLabel casilla=new JLabel("TUNEL",SwingConstants.CENTER);
        casilla.setOpaque(true);
        casilla.setBackground(Color.GREEN);
        ventana.add(casilla);
    }
}
